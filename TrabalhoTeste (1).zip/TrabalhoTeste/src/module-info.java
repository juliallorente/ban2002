/**
 * 
 */
/**
 * @author nickm
 *
 */
module TrabalhoTeste {
	requires java.sql;
}